$(document).ready(function(){
    $("#moveBtn").click(function(){
      $("#square").animate({left: "+=200px"}, 500);
    });
  });
  