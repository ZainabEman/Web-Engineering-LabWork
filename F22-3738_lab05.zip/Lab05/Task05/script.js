$(document).ready(function(){
    $("#natureBtn").click(function(){
      $("#bgImage").attr("src", "img/nature.jpg");
    });
    $("#cityBtn").click(function(){
      $("#bgImage").attr("src", "img/city.jpg");
    });
    $("#oceanBtn").click(function(){
      $("#bgImage").attr("src", "img/ocean.jpg");
    });
  });
  